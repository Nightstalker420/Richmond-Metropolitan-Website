# Richmond Metropolitan RP Website

A dark, blue-accented, mobile-friendly website for the Richmond Metropolitan Discord / Roblox roleplay community.

## Files
- `index.html` — website content
- `styles.css` — design and responsive layout
- `script.js` — mobile menu and notices
- `assets/richmond-metropolitan-logo.png` — supplied Richmond Metropolitan logo

## IMPORTANT: add your links
Open `index.html` and search for:
1. Discord invite is already configured: https://discord.gg/YPyQqVx4hz
2. `Google Staff Application URL` — replace the `href="#"` on the Staff application button.
3. `Department Application link` — replace the `href="#"` on the Department Applications button.

You can also replace the placeholder staff titles/names.

## GitHub Pages
1. Create a new GitHub repository, for example `Richmond-Metropolitan-Website`.
2. Upload everything inside this folder.
3. Go to Settings → Pages.
4. Under Build and deployment, choose `Deploy from a branch`.
5. Select `main` and `/ (root)`, then Save.
6. GitHub will give you your website address.

No server/database is required for the current version.
