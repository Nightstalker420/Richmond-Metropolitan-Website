const menuBtn = document.querySelector('.menu-btn');
const nav = document.querySelector('#nav');

menuBtn?.addEventListener('click', () => nav.classList.toggle('open'));
document.querySelectorAll('nav a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

function showNotice(event, message) {
  event.preventDefault();
  const box = document.getElementById('notice');
  box.textContent = message;
  box.classList.add('show');
  setTimeout(() => box.classList.remove('show'), 3500);
}
